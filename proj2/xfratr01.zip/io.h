/*
 * htab.h
 * Riešenie IJC=DU2, priklad b), 19.4.2022
 * Autor: Tomáš Frátrik (xfratr01), FIT
 * Preložene: gcc 9.4.0
 */

#ifndef __IO_H__
#define __IO_H__


int read_word(char *s, int max, FILE *f);


#endif